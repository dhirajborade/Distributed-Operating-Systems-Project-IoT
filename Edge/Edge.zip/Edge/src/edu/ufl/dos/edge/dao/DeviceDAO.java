package edu.ufl.dos.edge.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import edu.ufl.dos.edge.model.Device;

/**
 *Data access object class to get/modify device data. 
 *
 */
public class DeviceDAO {

	public static Map<String, Device> deviceMap = new HashMap<String, Device>();

	public static void main(String args[]) {
		//System.out.println("DeviceDAO main()");
	}

	static {
		try {
			List<Device> devices = DDLParser.getDeviceList();
			for (Device dev : devices) {
				String key = (dev.getBbbId() + "_" + dev.getDevId());
				System.out.println(key);
				deviceMap.put(key, dev);
			}
			UDPServer.initialize();
			UDPServer.startServer();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public List<Device> getAllDevices() {
		List<Device> devices = null;
		try {
			devices = DDLParser.getDeviceList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return devices;
	}

	public Device getDevice(int bbbId, int devId) {
		return deviceMap.get(bbbId + "_" + devId);
	}

	public void actuate(String bbbId, String devId, String state) {
		try {
			UDPClient.actuate(Integer.parseInt(state), Integer.parseInt(bbbId), Integer.parseInt(devId));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
